"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"
import { X, Cookie, Shield } from "lucide-react"

export function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false)
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    // Delay the appearance for better UX
    const timer = setTimeout(() => {
      const consent = localStorage.getItem("cookieConsent")
      if (!consent) {
        setShowConsent(true)
      }
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const acceptCookies = () => {
    localStorage.setItem("cookieConsent", "true")
    setShowConsent(false)
  }

  const declineCookies = () => {
    localStorage.setItem("cookieConsent", "false")
    setShowConsent(false)
  }

  if (!showConsent) return null

  return (
    <AnimatePresence>
      {showConsent && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
          className="fixed bottom-4 left-0 right-0 z-50 mx-auto max-w-screen-lg px-4"
        >
          <div className="relative overflow-hidden rounded-2xl bg-white shadow-2xl border border-gray-200">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 to-indigo-600"></div>

            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center">
                  <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
                    <Cookie className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold">Cookie-Einstellungen</h3>
                </div>
                <button
                  onClick={() => setShowConsent(false)}
                  className="rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-500"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="mb-6">
                <p className="text-gray-600">
                  Diese Website verwendet Cookies, um Ihr Browsing-Erlebnis zu verbessern und personalisierte Inhalte
                  bereitzustellen.
                </p>

                {expanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="mt-4"
                  >
                    <div className="rounded-lg bg-gray-50 p-4">
                      <div className="flex items-start mb-3">
                        <Shield className="mr-2 h-5 w-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Ihre Privatsphäre ist uns wichtig</h4>
                          <p className="text-sm text-gray-500">
                            Wir verwenden nur notwendige Cookies, um die Grundfunktionen der Website zu gewährleisten,
                            und mit Ihrer Zustimmung analytische Cookies, um zu verstehen, wie Sie mit unserer Website
                            interagieren.
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                <button
                  onClick={() => setExpanded(!expanded)}
                  className="mt-2 text-sm font-medium text-blue-600 hover:text-blue-800"
                >
                  {expanded ? "Weniger anzeigen" : "Mehr erfahren"}
                </button>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button onClick={acceptCookies} className="flex-1" variant="gradient">
                  Alle akzeptieren
                </Button>
                <Button onClick={declineCookies} variant="outline" className="flex-1">
                  Nur notwendige Cookies
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

