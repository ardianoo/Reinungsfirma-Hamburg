"use client"

import type { ReactNode } from "react"
import { motion } from "framer-motion"

interface SectionHeadingProps {
  title: string
  description?: string
  badge?: string
  align?: "left" | "center" | "right"
  titleClassName?: string
  descriptionClassName?: string
  gradient?: boolean
  children?: ReactNode
}

export function SectionHeading({
  title,
  description,
  badge,
  align = "center",
  titleClassName = "",
  descriptionClassName = "",
  gradient = true,
  children,
}: SectionHeadingProps) {
  const alignClass = {
    left: "items-start text-left",
    center: "items-center text-center",
    right: "items-end text-right",
  }[align]

  return (
    <motion.div
      className={`flex flex-col ${alignClass} space-y-4 mb-12`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
    >
      <div className="space-y-2">
        {badge && <div className="inline-block rounded-lg bg-gray-100 px-3 py-1 text-sm dark:bg-gray-800">{badge}</div>}
        <h2
          className={`text-3xl font-bold tracking-tighter sm:text-5xl ${gradient ? "gradient-text" : ""} ${titleClassName}`}
        >
          {title}
        </h2>
        {description && (
          <p
            className={`max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400 ${descriptionClassName}`}
          >
            {description}
          </p>
        )}
        {children}
      </div>
    </motion.div>
  )
}

