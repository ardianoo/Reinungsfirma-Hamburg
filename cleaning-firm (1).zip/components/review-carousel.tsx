"use client"

import { useEffect, useState, useRef } from "react"
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"

interface Review {
  name: string
  role: string
  content: string
  stars: number
  avatar?: string
}

interface ReviewCarouselProps {
  reviews: Review[]
  autoScrollInterval?: number
}

export function ReviewCarousel({ reviews, autoScrollInterval = 5000 }: ReviewCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!isPaused) {
      const timer = setInterval(() => {
        setActiveIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1))
      }, autoScrollInterval)
      return () => clearInterval(timer)
    }
  }, [isPaused, autoScrollInterval, reviews.length])

  const nextReview = () => {
    setActiveIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1))
  }

  const prevReview = () => {
    setActiveIndex((prev) => (prev === 0 ? reviews.length - 1 : prev - 1))
  }

  return (
    <div
      ref={containerRef}
      className="relative"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-2xl bg-white shadow-xl">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 to-indigo-600"></div>

          <div className="px-6 py-10 sm:px-10 sm:py-16">
            <div className="flex items-center justify-center mb-8">
              <motion.div
                className="flex space-x-1"
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              >
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-6 w-6 ${i < reviews[activeIndex].stars ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"}`}
                  />
                ))}
              </motion.div>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeIndex}
                initial={{ opacity: 0, y: 20, rotate: -5 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                exit={{ opacity: 0, y: -20, rotate: 5 }}
                transition={{ duration: 0.5 }}
                className="relative"
              >
                <div className="relative z-10">
                  <div className="relative">
                    <Quote className="absolute -top-6 -left-6 h-16 w-16 text-gray-100 transform -scale-x-100" />
                    <blockquote className="relative z-10">
                      <p className="text-center text-xl font-medium text-gray-700 sm:text-2xl">
                        "{reviews[activeIndex].content}"
                      </p>
                    </blockquote>
                  </div>

                  <div className="mt-8 flex flex-col items-center">
                    {reviews[activeIndex].avatar ? (
                      <div className="mb-4 h-14 w-14 overflow-hidden rounded-full border-2 border-white shadow-md">
                        <img
                          src={reviews[activeIndex].avatar || "/placeholder.svg"}
                          alt={reviews[activeIndex].name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xl font-bold">
                        {reviews[activeIndex].name.charAt(0)}
                      </div>
                    )}
                    <div className="text-center">
                      <p className="text-lg font-semibold text-gray-900">{reviews[activeIndex].name}</p>
                      <p className="text-sm text-gray-500">{reviews[activeIndex].role}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      <div className="absolute top-1/2 left-0 right-0 flex justify-between px-4 -translate-y-1/2">
        <Button
          onClick={prevReview}
          variant="outline"
          size="icon"
          className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white"
        >
          <ChevronLeft className="h-5 w-5" />
          <span className="sr-only">Previous review</span>
        </Button>
        <Button
          onClick={nextReview}
          variant="outline"
          size="icon"
          className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white"
        >
          <ChevronRight className="h-5 w-5" />
          <span className="sr-only">Next review</span>
        </Button>
      </div>
    </div>
  )
}

