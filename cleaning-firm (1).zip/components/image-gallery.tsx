"use client"

import { useState } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface GalleryImage {
  src: string
  alt: string
  width: number
  height: number
}

interface ImageGalleryProps {
  images: GalleryImage[]
  className?: string
}

export function ImageGallery({ images, className }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState(0)

  return (
    <div className={cn("space-y-4", className)}>
      <div className="relative aspect-video overflow-hidden rounded-lg">
        <Image
          src={images[selectedImage].src || "/placeholder.svg"}
          alt={images[selectedImage].alt}
          width={images[selectedImage].width}
          height={images[selectedImage].height}
          className="object-cover w-full h-full transition-all duration-300"
          priority
        />
      </div>
      <div className="grid grid-cols-5 gap-2">
        {images.map((image, index) => (
          <button
            key={index}
            onClick={() => setSelectedImage(index)}
            className={cn(
              "relative aspect-video overflow-hidden rounded-md transition-all",
              selectedImage === index ? "ring-2 ring-primary" : "opacity-70 hover:opacity-100",
            )}
          >
            <Image
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              width={100}
              height={60}
              className="object-cover w-full h-full"
            />
          </button>
        ))}
      </div>
    </div>
  )
}

