"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"

interface FeatureProps {
  title: string
  description: string
  features: string[]
  image: string
  decorativeImage: string
  learnMoreLink: string
  learnMoreText: string
  campaignBadge?: string
  discount?: string
  ctaText?: string
  serviceType: "büroreinigung" | "wohnungsreinigung"
}

export function FeatureSection({
  title,
  description,
  features,
  image,
  decorativeImage,
  learnMoreLink,
  learnMoreText,
  campaignBadge,
  discount,
  ctaText,
  serviceType,
}: FeatureProps) {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50 section-transition">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            {campaignBadge && (
              <span className="inline-block px-4 py-1.5 text-sm font-medium text-blue-800 bg-blue-100 rounded-full shadow-sm">
                {campaignBadge}
              </span>
            )}
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl lg:text-5xl gradient-text">
                Professionelle Büroreinigung
              </h2>
              <p className="text-gray-500 dark:text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Steigern Sie die Produktivität und das Wohlbefinden Ihrer Mitarbeiter mit unserer erstklassigen
                Büroreinigung. Saubere Arbeitsplätze sorgen für ein gesünderes Arbeitsumfeld.
              </p>
            </div>

            {discount && (
              <motion.div
                className="flex items-center p-5 bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200 rounded-2xl shadow-sm"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <div className="flex-shrink-0 mr-4">
                  <span className="flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-yellow-400 to-amber-400 text-white font-bold text-lg shadow-md">
                    %
                  </span>
                </div>
                <p className="font-medium text-amber-800">{discount}</p>
              </motion.div>
            )}

            <ul className="space-y-4">
              {features.map((feature, index) => (
                <motion.li
                  key={index}
                  className="flex items-start gap-3"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 * index }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 mt-1">
                    <span className="flex items-center justify-center w-7 h-7 rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-xs font-bold shadow-md">
                      ✓
                    </span>
                  </div>
                  <span className="text-base">{feature}</span>
                </motion.li>
              ))}
            </ul>

            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <Button
                asChild
                size="lg"
                className="font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl"
              >
                <Link href={learnMoreLink}>{ctaText || "Jetzt Angebot anfordern"}</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="font-semibold rounded-xl">
                <Link href={learnMoreLink}>{learnMoreText}</Link>
              </Button>
            </div>
          </motion.div>

          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative z-10 overflow-hidden rounded-3xl shadow-xl hover-scale">
              <img
                src={image || "/placeholder.svg"}
                alt="Professionelle Büroreinigung"
                className="w-full h-auto object-cover aspect-[4/3]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/70 to-transparent flex items-end">
                <div className="p-8 text-white">
                  <p className="text-2xl font-bold">Saubere Büros, produktivere Teams</p>
                  <p className="text-sm opacity-90">Professionelle Reinigung für Ihr Unternehmen</p>
                </div>
              </div>
            </div>

            <motion.div
              className="absolute -bottom-8 -right-8 z-0"
              animate={{
                rotate: [0, 10, 0, -10, 0],
                y: [0, -5, 0, 5, 0],
              }}
              transition={{
                repeat: Number.POSITIVE_INFINITY,
                duration: 5,
                ease: "easeInOut",
              }}
            >
              <img src={decorativeImage || "/placeholder.svg"} alt="" className="w-32 h-32" width={128} height={128} />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

