"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"

export function DiscountCode() {
  const [code, setCode] = useState("")
  const [isApplying, setIsApplying] = useState(false)

  const handleApplyCode = async () => {
    setIsApplying(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (code.toUpperCase() === "CLEAN20") {
      toast.success("Rabattcode erfolgreich eingelöst!")
      // Here you would typically update the prices or store the discount in state/context
    } else {
      toast.error("Ungültiger Rabattcode")
    }

    setIsApplying(false)
    setCode("")
  }

  return (
    <div className="flex flex-col items-center gap-4 p-4 rounded-lg border bg-muted">
      <p className="text-sm font-medium">Haben Sie einen Rabattcode?</p>
      <div className="flex gap-2 w-full max-w-sm">
        <Input
          placeholder="Code eingeben"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="uppercase"
        />
        <Button onClick={handleApplyCode} disabled={!code || isApplying}>
          {isApplying ? "Wird angewendet..." : "Einlösen"}
        </Button>
      </div>
    </div>
  )
}

