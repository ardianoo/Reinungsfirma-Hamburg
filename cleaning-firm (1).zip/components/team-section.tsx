"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface TeamMember {
  image: string
  role: string
  title: string
  description: string
  bgColor: string
}

export function TeamSection() {
  const teamMembers: TeamMember[] = [
    {
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-olly-3756679.jpg-Y0xNIb9OAySlLjHPFxi86wxNy135LI.jpeg",
      role: "Kundenbetreuung",
      title: "Persönliche Beratung",
      description:
        "Unsere Kundenberater stehen Ihnen zur Verfügung, um die perfekte Reinigungslösung für Ihre Bedürfnisse zu finden.",
      bgColor: "bg-gradient-to-br from-blue-100 to-blue-200",
    },
    {
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-olly-3824771.jpg-gAuli3uLbCHxb6B8ryLrsHrhahCt8p.jpeg",
      role: "Geschäftsführung",
      title: "Erfahrene Leitung",
      description:
        "Mit jahrelanger Erfahrung in der Reinigungsbranche garantieren wir höchste Qualität und Kundenzufriedenheit.",
      bgColor: "bg-gradient-to-br from-green-100 to-green-200",
    },
    {
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-mastercowley-713297.jpg-UOGRjOjVwi5BFTxeSVldIrAWvxNABX.jpeg",
      role: "Reinigungsteam",
      title: "Professionelle Reinigung",
      description:
        "Unser geschultes Reinigungsteam arbeitet sorgfältig und effizient, um Ihre Räume in neuem Glanz erstrahlen zu lassen.",
      bgColor: "bg-gradient-to-br from-pink-100 to-pink-200",
    },
    {
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-yankrukov-7691739.jpg-FXzHvDJSnzwWeYuMGB7st6NDIx8vFh.jpeg",
      role: "Projektleitung",
      title: "Kompetente Koordination",
      description:
        "Unsere Projektleiter koordinieren die Einsätze und stellen sicher, dass alle Reinigungsarbeiten nach Plan verlaufen.",
      bgColor: "bg-gradient-to-br from-yellow-100 to-yellow-200",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-50 section-transition">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl gradient-text mb-4">Unser erfahrenes Team</h2>
          <p className="mt-4 text-gray-500 md:text-xl max-w-3xl mx-auto">
            Lernen Sie die Menschen kennen, die täglich für Ihre Sauberkeit und Ihr Wohlbefinden sorgen.
          </p>
        </div>

        {/* Rest of the component remains the same */}
        <div className="relative">
          <div className="absolute inset-0 z-0 overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-blue-400/20 rounded-full -translate-x-1/2 -translate-y-1/2 blur-xl" />
            <div className="absolute top-1/3 right-0 w-48 h-48 bg-blue-400/20 rounded-full translate-x-1/4 blur-xl" />
            <div className="absolute bottom-0 left-1/2 w-40 h-40 bg-blue-400/20 rounded-full -translate-x-1/2 translate-y-1/4 blur-xl" />
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 relative z-10">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex flex-col items-center card-hover"
              >
                <motion.div
                  className={`rounded-full p-4 ${member.bgColor} w-48 h-48 relative overflow-hidden mb-6 mx-auto shadow-lg`}
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <Image
                    src={member.image || "/placeholder.svg"}
                    alt={member.role}
                    fill
                    className="object-cover rounded-full"
                  />
                </motion.div>
                <h3 className="text-xl font-bold mb-2 text-blue-600">{member.role}</h3>
                <h4 className="text-lg font-semibold mb-3">{member.title}</h4>
                <p className="text-gray-500 text-center">{member.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

