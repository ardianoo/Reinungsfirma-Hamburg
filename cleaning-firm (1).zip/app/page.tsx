import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { ReviewCarousel } from "@/components/review-carousel"
import { SiteFooter } from "@/components/site-footer"
import { TeamSection } from "@/components/team-section"

export default function Home() {
  // Define the reviews data with more reviews
  const reviews = [
    {
      name: "Sarah Johnson",
      role: "Büroleitung",
      content:
        "Das Team von CleanPro hat bei unserem Büro hervorragende Arbeit geleistet. Sie waren gründlich, professionell und haben alles makellos hinterlassen. Sehr empfehlenswert!",
      stars: 5,
      avatar: "/placeholder.svg?height=56&width=56",
    },
    {
      name: "Michael Davis",
      role: "Hausbesitzer",
      content:
        "Ich nutze CleanPro seit über einem Jahr für meine Hausreinigung und könnte nicht glücklicher sein. Sie sind zuverlässig, gründlich und gehen immer die extra Meile.",
      stars: 5,
      avatar: "/placeholder.svg?height=56&width=56",
    },
    {
      name: "Jennifer Lee",
      role: "Wohnungsbewohnerin",
      content:
        "Der Grundreinigungsservice war außergewöhnlich. Sie haben unsere Wohnung verwandelt und sie wie neu aussehen lassen. Jeden Cent wert!",
      stars: 5,
      avatar: "/placeholder.svg?height=56&width=56",
    },
    {
      name: "Thomas Müller",
      role: "Geschäftsführer",
      content:
        "CleanPro hat unsere Erwartungen übertroffen. Die Reinigungsteams sind pünktlich, professionell und sehr gründlich. Wir werden definitiv wieder buchen!",
      stars: 5,
      avatar: "/placeholder.svg?height=56&width=56",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold text-xl">Reinigungsteam Hamburg</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/" className="transition-colors hover:text-primary">
                Startseite
              </Link>
              <Link href="/services" className="transition-colors hover:text-primary">
                Leistungen
              </Link>
              <Link href="/pricing" className="transition-colors hover:text-primary">
                Preise
              </Link>
              <Link href="/contact" className="transition-colors hover:text-primary">
                Kontakt
              </Link>
            </nav>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <Button asChild className="hidden md:flex">
              <Link href="/book">Jetzt Buchen</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl gradient-text">
                  Professionelle Reinigungsdienstleistungen für Ihr Zuhause & Büro
                </h1>
                <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Wir bieten hochwertige Reinigungsdienstleistungen, die auf Ihre Bedürfnisse zugeschnitten sind. Unser
                  professionelles Team sorgt dafür, dass Ihre Räume makellos und gesund sind.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button asChild size="lg" variant="gradient">
                    <Link href="/book">Reinigung Buchen</Link>
                  </Button>
                  <Button variant="outline" size="lg" asChild>
                    <Link href="/services">
                      Unsere Leistungen
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="mx-auto w-full max-w-[500px] lg:max-w-none">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-chaitaastic-1918291.jpg-1Zy1PbcWtjlCt9sdKv1G3cBswE3Mav.jpeg"
                  alt="Moderne Wohnung nach der Reinigung"
                  className="w-full h-auto rounded-2xl shadow-lg object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-4 text-center card-hover p-6 rounded-2xl bg-white shadow-sm">
              <div className="aspect-video rounded-lg overflow-hidden mb-4">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-seven11nash-380768.jpg-9hF8kJt0b0shvapHKb8MlOWKut0zzR.jpeg"
                  alt="Büroreinigung"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="grid gap-4 text-center card-hover p-6 rounded-2xl bg-white shadow-sm">
              <div className="aspect-video rounded-lg overflow-hidden mb-4">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-ketut-subiyanto-4245922.jpg-zgtXrp8cDHtANbDLj1HPbm9MvpG0I2.jpeg"
                  alt="Ein-/Auszugsreinigung"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="grid gap-4 text-center card-hover p-6 rounded-2xl bg-white shadow-sm">
              <div className="aspect-video rounded-lg overflow-hidden mb-4">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-chaitaastic-1918291.jpg-1Zy1PbcWtjlCt9sdKv1G3cBswE3Mav.jpeg"
                  alt="Wohnungsreinigung"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <TeamSection />
        <ReviewCarousel reviews={reviews} />
      </main>
      <SiteFooter />
    </div>
  )
}

