import Link from "next/link"
import { Mail, MapPin, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { MapContainer } from "@/components/map-container"
import { SiteFooter } from "@/components/site-footer"

export default function ContactPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold text-xl">Reinigungsteam Hamburg</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/" className="transition-colors hover:text-primary">
                Startseite
              </Link>
              <Link href="/services" className="transition-colors hover:text-primary">
                Leistungen
              </Link>
              <Link href="/pricing" className="transition-colors hover:text-primary">
                Preise
              </Link>
              <Link href="/about" className="transition-colors hover:text-primary">
                Über uns
              </Link>
              <Link href="/contact" className="transition-colors hover:text-primary text-primary">
                Kontakt
              </Link>
            </nav>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <Button asChild className="hidden md:flex">
              <Link href="/book">Jetzt Buchen</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Kontaktieren Sie uns</h1>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Haben Sie Fragen oder benötigen Sie ein Angebot? Nehmen Sie Kontakt mit unserem Team auf.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-8">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter">Nehmen Sie Kontakt auf</h2>
                  <p className="text-gray-500 dark:text-gray-400">
                    Wir sind hier, um Ihnen bei allen Fragen zu unseren Reinigungsdienstleistungen zu helfen.
                  </p>
                </div>

                <div className="grid gap-6">
                  <Card>
                    <CardContent className="p-6 flex items-start gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        <Phone className="h-6 w-6" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="font-bold">Telefon</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Rufen Sie uns direkt an</p>
                        <p className="font-medium">(123) 456-7890</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6 flex items-start gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        <Mail className="h-6 w-6" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="font-bold">E-Mail</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Senden Sie uns eine E-Mail</p>
                        <p className="font-medium">info@hamburg-reinigungsteam.de</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6 flex items-start gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        <MapPin className="h-6 w-6" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="font-bold">Standort</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Hamburg</p>
                        <p className="font-medium">HafenCity</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Unser Standort</CardTitle>
                    <CardDescription>Besuchen Sie uns in Hamburg</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <MapContainer />
                  </CardContent>
                </Card>

                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Geschäftszeiten</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>Montag - Freitag</div>
                    <div>8:00 - 18:00 Uhr</div>
                    <div>Samstag</div>
                    <div>9:00 - 16:00 Uhr</div>
                    <div>Sonntag</div>
                    <div>Geschlossen</div>
                  </div>
                </div>
              </div>

              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Senden Sie uns eine Nachricht</CardTitle>
                    <CardDescription>
                      Füllen Sie das Formular unten aus und wir werden uns so schnell wie möglich bei Ihnen melden.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="first-name">Vorname</Label>
                        <Input id="first-name" placeholder="Max" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="last-name">Nachname</Label>
                        <Input id="last-name" placeholder="Mustermann" />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="email">E-Mail</Label>
                      <Input id="email" type="email" placeholder="max@beispiel.de" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="phone">Telefon</Label>
                      <Input id="phone" type="tel" placeholder="0123 456789" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="subject">Betreff</Label>
                      <Input id="subject" placeholder="Wie können wir Ihnen helfen?" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="message">Nachricht</Label>
                      <Textarea
                        id="message"
                        placeholder="Bitte geben Sie Details zu Ihrer Anfrage an..."
                        className="min-h-[120px]"
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Nachricht senden</Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Häufig gestellte Fragen</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Finden Sie Antworten auf häufig gestellte Fragen zu unseren Reinigungsdienstleistungen
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Wie plane ich einen Reinigungsservice?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>
                    Sie können einen Reinigungsservice über unser Online-Buchungssystem planen, unseren Kundenservice
                    anrufen oder uns eine E-Mail senden. Wir werden umgehend antworten, um Ihren Termin zu bestätigen.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Was ist in Ihrem Standard-Reinigungsservice enthalten?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>
                    Unser Standard-Reinigungsservice umfasst Abstauben, Staubsaugen, Wischen, Badezimmerreinigung,
                    Küchenreinigung und allgemeines Aufräumen. Eine detaillierte Liste der Aufgaben finden Sie auf
                    unserer Leistungsseite.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Muss ich Reinigungsmittel bereitstellen?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>
                    Nein, unser professionelles Reinigungsteam bringt alle notwendigen Reinigungsmittel und Geräte mit.
                    Wir verwenden umweltfreundliche Produkte, die für Ihre Familie und Haustiere unbedenklich sind.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Wie berechnen Sie Ihre Reinigungsdienstleistungen?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>
                    Unsere Preise basieren auf der Größe Ihrer Immobilie, der Art des gewünschten Reinigungsservices und
                    der Häufigkeit des Services. Wir bieten kostenlose Schätzungen an, um Ihnen ein genaues Angebot zu
                    unterbreiten.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}

