"use client"
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover"
import { useState } from "react"
import Link from "next/link"
import { CalendarIcon, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"

export default function BookingPage() {
  const [date, setDate] = useState<Date>()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    service: "",
    propertyType: "",
  })

  const handleChange = (field: string, value: any) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const nextStep = () => {
    setStep(2)
    window.scrollTo(0, 0)
  }

  const prevStep = () => {
    setStep(1)
    window.scrollTo(0, 0)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold text-xl">Reinigungsteam Hamburg</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/" className="transition-colors hover:text-primary">
                Startseite
              </Link>
              <Link href="/services" className="transition-colors hover:text-primary">
                Leistungen
              </Link>
              <Link href="/pricing" className="transition-colors hover:text-primary">
                Preise
              </Link>
              <Link href="/about" className="transition-colors hover:text-primary">
                Über uns
              </Link>
              <Link href="/contact" className="transition-colors hover:text-primary">
                Kontakt
              </Link>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12 md:py-24 lg:py-32 bg-muted/40">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Buchen Sie Ihren Reinigungsservice</h1>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                Planen Sie Ihren Reinigungstermin in nur wenigen einfachen Schritten
              </p>
            </div>
          </div>

          <div className="flex justify-center mb-8">
            <div className="flex items-center">
              <div
                className={`flex items-center justify-center w-10 h-10 rounded-full ${
                  step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                1
              </div>
              <div className={`w-16 h-1 ${step >= 2 ? "bg-primary" : "bg-muted"}`}></div>
              <div
                className={`flex items-center justify-center w-10 h-10 rounded-full ${
                  step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                2
              </div>
            </div>
          </div>

          <Card className="max-w-2xl mx-auto">
            {step === 1 && (
              <>
                <CardHeader>
                  <CardTitle>Wählen Sie Ihren Service</CardTitle>
                  <CardDescription>Wählen Sie die Art des Reinigungsservice, den Sie benötigen</CardDescription>
                </CardHeader>
                <CardContent>
                  <form>
                    <div className="grid gap-6">
                      <div className="grid gap-2">
                        <Select value={formData.service} onValueChange={(value) => handleChange("service", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Wählen Sie einen Service" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="residential">Wohnungsreinigung</SelectItem>
                            <SelectItem value="commercial">Büroreinigung</SelectItem>
                            <SelectItem value="move-in-out">Ein-/Auszugsreinigung</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-2">
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !date && "text-muted-foreground",
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {date ? date.toLocaleDateString() : "Wunschtermin auswählen"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={date}
                              onSelect={setDate}
                              initialFocus
                              disabled={(date) => {
                                const today = new Date()
                                today.setHours(0, 0, 0, 0)
                                return date < today
                              }}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>
                  </form>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" asChild>
                    <Link href="/">Abbrechen</Link>
                  </Button>
                  <Button onClick={nextStep} disabled={!formData.service || !date}>
                    Weiter zur Kontaktaufnahme
                  </Button>
                </CardFooter>
              </>
            )}

            {step === 2 && (
              <>
                <CardHeader>
                  <CardTitle>Kontaktaufnahme</CardTitle>
                  <CardDescription>
                    Für weitere Informationen und zur Terminbestätigung kontaktieren Sie uns bitte per E-Mail
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg bg-muted p-6">
                    <div className="flex items-center gap-4">
                      <Mail className="h-6 w-6 text-primary" />
                      <div>
                        <h3 className="font-semibold">Kontaktieren Sie uns</h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          Senden Sie uns eine E-Mail mit Ihren Details und Wünschen
                        </p>
                        <a
                          href="mailto:info@hamburg-reinigungsteam.de"
                          className="text-primary hover:underline font-medium"
                        >
                          info@hamburg-reinigungsteam.de
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium">Ihre ausgewählten Details:</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      <li>
                        Service: {formData.service === "residential" && "Wohnungsreinigung"}
                        {formData.service === "commercial" && "Büroreinigung"}
                        {formData.service === "move-in-out" && "Ein-/Auszugsreinigung"}
                      </li>
                      <li>Wunschtermin: {date?.toLocaleDateString()}</li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={prevStep}>
                    Zurück
                  </Button>
                  <Button asChild variant="default">
                    <a href="mailto:info@hamburg-reinigungsteam.de">E-Mail senden</a>
                  </Button>
                </CardFooter>
              </>
            )}
          </Card>
        </div>
      </main>
    </div>
  )
}

