import Link from "next/link"
import { Check, Sparkles } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { SiteFooter } from "@/components/site-footer"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TeamSection } from "@/components/team-section"
import { StatsSection } from "@/components/stats-section"

export default function PricingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold text-xl">CleanPro</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/" className="transition-colors hover:text-primary">
                Startseite
              </Link>
              <Link href="/services" className="transition-colors hover:text-primary">
                Leistungen
              </Link>
              <Link href="/pricing" className="transition-colors hover:text-primary text-primary">
                Preise
              </Link>
              <Link href="/about" className="transition-colors hover:text-primary">
                Über uns
              </Link>
              <Link href="/contact" className="transition-colors hover:text-primary">
                Kontakt
              </Link>
            </nav>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <Button asChild className="hidden md:flex">
              <Link href="/book">Jetzt Buchen</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Unsere Preise</h1>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Transparente Preisgestaltung für alle Ihre Reinigungsbedürfnisse
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-sm rounded-lg border bg-yellow-50 border-yellow-200 p-4 mb-12">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-yellow-600" />
                <p className="text-sm font-medium text-yellow-800">
                  Sonderaktion: 20% Rabatt auf Ihre erste Buchung mit dem Code{" "}
                  <span className="font-bold">CLEAN20</span>
                </p>
              </div>
            </div>

            <Tabs defaultValue="residential" className="max-w-4xl mx-auto">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="residential">Wohnungsreinigung</TabsTrigger>
                <TabsTrigger value="commercial">Büroreinigung</TabsTrigger>
                <TabsTrigger value="move">Ein-/Auszugsreinigung</TabsTrigger>
              </TabsList>
              <TabsContent value="residential">
                <div className="grid gap-8 md:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <CardTitle>Basis</CardTitle>
                      <CardDescription>Für kleine Wohnungen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €99
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€125</span>
                      </p>
                      <p className="text-sm text-gray-500">pro Reinigung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Bis zu 60m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Staubsaugen und Wischen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Badezimmerreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Küchenreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Abstauben</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=residential&plan=basic">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card className="border-primary">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Standard</CardTitle>
                        <Badge>Beliebt</Badge>
                      </div>
                      <CardDescription>Für mittelgroße Wohnungen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €149
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€189</span>
                      </p>
                      <p className="text-sm text-gray-500">pro Reinigung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>60-100m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Alle Basis-Leistungen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Fensterputzen innen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Wäsche waschen und falten</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Bettwäsche wechseln</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=residential&plan=standard">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Premium</CardTitle>
                      <CardDescription>Für große Wohnungen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €199
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€250</span>
                      </p>
                      <p className="text-sm text-gray-500">pro Reinigung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>100-150m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Alle Standard-Leistungen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Schrankreinigung innen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Kühlschrankreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Backofen- und Herdreinigung</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=residential&plan=premium">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="commercial">
                <div className="grid gap-8 md:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <CardTitle>Basis</CardTitle>
                      <CardDescription>Für kleine Büros</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €149
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€189</span>
                      </p>
                      <p className="text-sm text-gray-500">pro Reinigung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Bis zu 100m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Staubsaugen und Wischen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Sanitärreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Küchenbereich reinigen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Müllentsorgung</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=commercial&plan=basic">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card className="border-primary">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Standard</CardTitle>
                        <Badge>Beliebt</Badge>
                      </div>
                      <CardDescription>Für mittelgroße Büros</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €249
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€310</span>
                      </p>
                      <p className="text-sm text-gray-500">pro Reinigung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>100-200m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Alle Basis-Leistungen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Fensterputzen innen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Desinfizieren von Oberflächen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Staubwischen von Geräten</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=commercial&plan=standard">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Premium</CardTitle>
                      <CardDescription>Für große Büroflächen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €399
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€499</span>
                      </p>
                      <p className="text-sm text-gray-500">pro Reinigung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>200-400m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Alle Standard-Leistungen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Teppichreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Polsterreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Außenfensterreinigung</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=commercial&plan=premium">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="move">
                <div className="grid gap-8 md:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <CardTitle>Basis</CardTitle>
                      <CardDescription>Für kleine Wohnungen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €199
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€249</span>
                      </p>
                      <p className="text-sm text-gray-500">Einmalzahlung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Bis zu 60m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Grundreinigung aller Räume</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Badezimmertiefenreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Küchenreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Fensterreinigung innen</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=move-in-out&plan=basic">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card className="border-primary">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Standard</CardTitle>
                        <Badge>Beliebt</Badge>
                      </div>
                      <CardDescription>Für mittelgroße Wohnungen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €299
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€375</span>
                      </p>
                      <p className="text-sm text-gray-500">Einmalzahlung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>60-100m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Alle Basis-Leistungen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Schrankreinigung innen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Reinigung von Lichtschaltern</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Entfernung von Kleberesten</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=move-in-out&plan=standard">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Premium</CardTitle>
                      <CardDescription>Für große Wohnungen</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">
                        €399
                        <span className="text-sm font-normal text-gray-500 line-through ml-2">€499</span>
                      </p>
                      <p className="text-sm text-gray-500">Einmalzahlung</p>
                      <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>100-150m²</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Alle Standard-Leistungen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Fensterreinigung außen</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Balkon-/Terrassenreinigung</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-primary" />
                          <span>Tiefenreinigung von Geräten</span>
                        </li>
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href="/book?service=move-in-out&plan=premium">Jetzt Buchen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <TeamSection />
        <StatsSection />

        <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Bereit für ein sauberes Zuhause?</h2>
                <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Buchen Sie jetzt und erhalten Sie 20% Rabatt auf Ihre erste Reinigung
                </p>
              </div>
              <Button asChild size="lg" variant="secondary">
                <Link href="/book">Jetzt Buchen</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}

