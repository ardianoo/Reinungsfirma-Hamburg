"use client"

import { useEffect, useRef, useState } from "react"
import { motion, useInView } from "framer-motion"

interface Stat {
  value: number
  suffix: string
  label: string
}

export function StatsSection() {
  const stats: Stat[] = [
    {
      value: 1200,
      suffix: "+",
      label: "Unternehmen setzen auf CleanPro",
    },
    {
      value: 17,
      suffix: "+",
      label: "Jahre Entwicklung von Profis für Profis",
    },
    {
      value: 17500,
      suffix: "+",
      label: "User nutzen bereits die CleanPro App",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50 section-transition">
      <div className="container px-4 md:px-6">
        <div className="grid gap-12 md:grid-cols-3">
          {stats.map((stat, index) => (
            <CounterCard key={index} {...stat} index={index} />
          ))}
        </div>
        <motion.div
          className="mt-20 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl gradient-text mb-4">
            CleanPro ist sicher und ausgezeichnet
          </h2>
          <p className="mt-4 text-gray-500 md:text-xl max-w-3xl mx-auto">
            Ihre Daten sind uns heilig: Wir bieten höchste Sicherheit und besten Schutz für Ihr wichtigstes Gut. Darauf
            können Sie sich verlassen.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

function CounterCard({ value, suffix, label, index }: Stat & { index: number }) {
  const [counter, setCounter] = useState(0)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.5 })

  useEffect(() => {
    if (isInView) {
      const duration = 2000 // 2 seconds
      const steps = 60
      const stepValue = value / steps
      let current = 0

      const timer = setInterval(() => {
        current += stepValue
        if (current >= value) {
          setCounter(value)
          clearInterval(timer)
        } else {
          setCounter(Math.floor(current))
        }
      }, duration / steps)

      return () => clearInterval(timer)
    }
  }, [isInView, value])

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="text-center bg-white/50 backdrop-blur-sm rounded-2xl p-8 shadow-lg card-hover"
    >
      <div className="text-5xl md:text-6xl lg:text-7xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
        {counter}
        {suffix}
      </div>
      <p className="mt-2 text-gray-600 font-medium">{label}</p>
    </motion.div>
  )
}

