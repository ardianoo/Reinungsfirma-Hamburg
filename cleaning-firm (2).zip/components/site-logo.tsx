import Link from "next/link"

interface SiteLogoProps {
  className?: string
}

export function SiteLogo({ className }: SiteLogoProps) {
  return (
    <Link href="/" className={`flex items-center ${className}`}>
      <span className="font-bold text-xl">Reinigungsteam Hamburg</span>
    </Link>
  )
}

