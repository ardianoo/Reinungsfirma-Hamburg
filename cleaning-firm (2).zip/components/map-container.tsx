"use client"

import { useState, useEffect } from "react"

export function MapContainer() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Delay loading the map until component is mounted
    setIsLoaded(true)
  }, [])

  return (
    <div className="w-full h-[400px] rounded-md overflow-hidden bg-gray-100">
      {isLoaded ? (
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18874.772036193223!2d9.986576677709961!3d53.54019895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47b18efd3dda753b%3A0x426b0c153fd082a0!2sHafenCity%2C%20Hamburg%2C%20Germany!5e0!3m2!1sen!2sus!4v1690670567178!5m2!1sen!2sus"
          width="100%"
          height="100%"
          style={{ border: 0 }}
          allowFullScreen={false}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Standort in Hamburg"
        ></iframe>
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <p className="text-gray-500">Karte wird geladen...</p>
        </div>
      )}
    </div>
  )
}

