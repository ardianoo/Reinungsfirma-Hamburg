"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { SiteLogo } from "@/components/site-logo"
import { motion, AnimatePresence } from "framer-motion"

export function MobileHeader() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  return (
    <>
      <div className="container flex h-16 items-center justify-between md:hidden">
        <SiteLogo />
        <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Toggle menu">
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 bg-background md:hidden"
          >
            <div className="container flex h-16 items-center justify-between">
              <SiteLogo />
              <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Close menu">
                <X className="h-6 w-6" />
              </Button>
            </div>
            <nav className="container grid gap-6 py-8">
              <Link
                href="/"
                className="flex items-center justify-between py-3 text-lg font-medium border-b"
                onClick={toggleMenu}
              >
                Startseite
              </Link>
              <Link
                href="/services"
                className="flex items-center justify-between py-3 text-lg font-medium border-b"
                onClick={toggleMenu}
              >
                Leistungen
              </Link>
              <Link
                href="/pricing"
                className="flex items-center justify-between py-3 text-lg font-medium border-b"
                onClick={toggleMenu}
              >
                Preise
              </Link>
              <Link
                href="/contact"
                className="flex items-center justify-between py-3 text-lg font-medium border-b"
                onClick={toggleMenu}
              >
                Kontakt
              </Link>
              <div className="mt-6">
                <Button asChild className="w-full" size="lg">
                  <Link href="/book" onClick={toggleMenu}>
                    Jetzt Buchen
                  </Link>
                </Button>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

