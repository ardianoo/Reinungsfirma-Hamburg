"use client"

import type { ReactNode } from "react"
import { motion } from "framer-motion"

interface LayoutSectionProps {
  children: ReactNode
  className?: string
  background?: "white" | "light" | "gradient" | "none"
  containerClassName?: string
  animate?: boolean
}

export function LayoutSection({
  children,
  className = "",
  background = "white",
  containerClassName = "",
  animate = true,
}: LayoutSectionProps) {
  const getBgClass = () => {
    switch (background) {
      case "white":
        return "bg-white"
      case "light":
        return "bg-gray-50"
      case "gradient":
        return "bg-gradient-to-r from-blue-50 to-indigo-50"
      default:
        return ""
    }
  }

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1,
      },
    },
  }

  return (
    <section className={`w-full py-12 md:py-24 lg:py-32 ${getBgClass()} ${className}`}>
      <div className={`container px-4 md:px-6 ${containerClassName}`}>
        {animate ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
          >
            {children}
          </motion.div>
        ) : (
          children
        )}
      </div>
    </section>
  )
}

