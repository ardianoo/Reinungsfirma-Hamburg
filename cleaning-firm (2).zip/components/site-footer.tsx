"use client"

import Link from "next/link"
import { MapPin, Phone, Mail } from "lucide-react"
import { motion } from "framer-motion"

export function SiteFooter() {
  return (
    <footer className="w-full py-12 md:py-16 bg-gradient-to-b from-gray-50 to-gray-100 border-t">
      <div className="container px-4 md:px-6">
        <div className="grid gap-10 md:grid-cols-3">
          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h4 className="text-xl font-bold gradient-text">Reinigungsteam Hamburg</h4>
            <p className="text-gray-500">
              Professionelle Reinigungsdienstleistungen für Ihr Zuhause und Büro. Qualität, die Sie sehen können.
            </p>
          </motion.div>

          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="text-lg font-semibold">Rechtliches</h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link href="/datenschutz" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Datenschutzerklärung
                </Link>
              </li>
              <li>
                <Link href="/impressum" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Impressum
                </Link>
              </li>
              <li>
                <Link href="/cookies" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Cookie-Einstellungen
                </Link>
              </li>
            </ul>
          </motion.div>

          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="text-lg font-semibold">Kontakt</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 mt-0.5 text-blue-600" />
                <span className="text-gray-500">HafenCity, Hamburg</span>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 mt-0.5 text-blue-600" />
                <span className="text-gray-500">+49 176 23721485</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 mt-0.5 text-blue-600" />
                <span className="text-gray-500">info@hamburg-reinigungsteam.de</span>
              </li>
            </ul>
          </motion.div>
        </div>

        <div className="mt-12 pt-8 border-t text-center">
          <p className="text-sm text-gray-500">© 2025 Reinigungsteam Hamburg. Alle Rechte vorbehalten.</p>
        </div>
      </div>
    </footer>
  )
}

