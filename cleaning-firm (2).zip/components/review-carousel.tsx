"use client"

import { useEffect, useState, useRef } from "react"
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"

interface Review {
  name: string
  role: string
  content: string
  stars: number
  avatar?: string
}

interface ReviewCarouselProps {
  reviews: Review[]
  autoScrollInterval?: number
}

export function ReviewCarousel({ reviews, autoScrollInterval = 5000 }: ReviewCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!isPaused) {
      const timer = setInterval(() => {
        setActiveIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1))
      }, autoScrollInterval)
      return () => clearInterval(timer)
    }
  }, [isPaused, autoScrollInterval, reviews.length])

  const nextReview = () => {
    setActiveIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1))
  }

  const prevReview = () => {
    setActiveIndex((prev) => (prev === 0 ? reviews.length - 1 : prev - 1))
  }

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-indigo-50">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl gradient-text mb-4">
            Was unsere Kunden sagen
          </h2>
          <p className="text-gray-500 md:text-xl max-w-3xl mx-auto">
            Erfahren Sie, warum unsere Kunden uns vertrauen und immer wieder buchen
          </p>
        </div>

        <div
          ref={containerRef}
          className="relative max-w-5xl mx-auto"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <div className="relative overflow-hidden rounded-2xl bg-white shadow-xl">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-600 to-indigo-600"></div>

            <div className="px-8 py-12 sm:px-12 sm:py-16">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeIndex}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.5 }}
                  className="relative"
                >
                  <div className="flex flex-col gap-6">
                    <div className="relative">
                      <Quote className="absolute -top-6 -left-6 h-16 w-16 text-blue-100 transform -scale-x-100" />
                      <blockquote className="relative z-10">
                        <p className="text-xl md:text-2xl font-medium text-gray-700 italic">
                          "{reviews[activeIndex].content}"
                        </p>
                      </blockquote>
                    </div>

                    <div className="flex flex-col items-center">
                      <p className="text-xl font-semibold text-gray-900">{reviews[activeIndex].name}</p>
                      <p className="text-sm text-gray-500 mb-2">{reviews[activeIndex].role}</p>

                      <div className="flex space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < reviews[activeIndex].stars
                                ? "fill-yellow-400 text-yellow-400"
                                : "fill-gray-200 text-gray-200"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
              {reviews.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    activeIndex === index ? "bg-blue-600 w-8" : "bg-gray-300 hover:bg-gray-400"
                  }`}
                  aria-label={`Go to review ${index + 1}`}
                />
              ))}
            </div>
          </div>

          <div className="absolute top-1/2 -left-4 -right-4 flex justify-between -translate-y-1/2">
            <Button
              onClick={prevReview}
              variant="outline"
              size="icon"
              className="rounded-full bg-white/90 backdrop-blur-sm hover:bg-white shadow-lg"
            >
              <ChevronLeft className="h-5 w-5" />
              <span className="sr-only">Previous review</span>
            </Button>
            <Button
              onClick={nextReview}
              variant="outline"
              size="icon"
              className="rounded-full bg-white/90 backdrop-blur-sm hover:bg-white shadow-lg"
            >
              <ChevronRight className="h-5 w-5" />
              <span className="sr-only">Next review</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

