"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { ArrowUpRight, Users, Home, CheckCircle, Clock } from "lucide-react"
import Link from "next/link"

export function DashboardPreview() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-gray-50 to-white">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl gradient-text">
              Professionelles Reinigungsmanagement
            </h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Verwalten Sie Ihre Reinigungstermine und verfolgen Sie den Fortschritt mit unserem benutzerfreundlichen
              Dashboard
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="rounded-xl border bg-background shadow-xl overflow-hidden"
          >
            <div className="flex flex-col md:flex-row">
              {/* Sidebar */}
              <div className="w-full md:w-64 bg-gray-50 border-r p-4">
                <div className="flex items-center gap-2 mb-8">
                  <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                    <Users className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-medium">Kundenportal</p>
                    <p className="text-xs text-gray-500">Reinigungsteam Hamburg</p>
                  </div>
                </div>

                <nav className="space-y-1">
                  <div className="flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-2 rounded-md">
                    <Home className="h-4 w-4" />
                    <span className="text-sm font-medium">Dashboard</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700 px-3 py-2 rounded-md hover:bg-gray-100">
                    <Calendar className="h-4 w-4" />
                    <span className="text-sm font-medium">Termine</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700 px-3 py-2 rounded-md hover:bg-gray-100">
                    <CheckCircle className="h-4 w-4" />
                    <span className="text-sm font-medium">Leistungen</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700 px-3 py-2 rounded-md hover:bg-gray-100">
                    <Clock className="h-4 w-4" />
                    <span className="text-sm font-medium">Verlauf</span>
                  </div>
                </nav>
              </div>

              {/* Main content */}
              <div className="flex-1 p-6">
                <Tabs defaultValue="overview">
                  <div className="flex justify-between items-center mb-6">
                    <TabsList>
                      <TabsTrigger value="overview">Übersicht</TabsTrigger>
                      <TabsTrigger value="schedule">Zeitplan</TabsTrigger>
                      <TabsTrigger value="reports">Berichte</TabsTrigger>
                    </TabsList>

                    <Button size="sm" asChild>
                      <Link href="/book">
                        Neuer Termin
                        <ArrowUpRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>

                  <TabsContent value="overview" className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-3">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                          <CardTitle className="text-sm font-medium">Nächste Reinigung</CardTitle>
                          <Clock className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">Morgen, 10:00 Uhr</div>
                          <p className="text-xs text-muted-foreground">Wohnungsreinigung</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                          <CardTitle className="text-sm font-medium">Abgeschlossene Reinigungen</CardTitle>
                          <CheckCircle className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">12</div>
                          <p className="text-xs text-muted-foreground">+2 seit letztem Monat</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                          <CardTitle className="text-sm font-medium">Zufriedenheit</CardTitle>
                          <Users className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">98%</div>
                          <p className="text-xs text-muted-foreground">+4% seit letztem Monat</p>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                      <Card className="md:col-span-4">
                        <CardHeader>
                          <CardTitle>Reinigungsaktivität</CardTitle>
                        </CardHeader>
                        <CardContent className="pl-2">
                          <div className="h-[200px] w-full flex items-end gap-2">
                            {[40, 25, 55, 32, 80, 45, 60].map((height, i) => (
                              <div key={i} className="relative h-full flex-1 flex items-end">
                                <div className="w-full bg-blue-500 rounded-t-sm" style={{ height: `${height}%` }}></div>
                              </div>
                            ))}
                          </div>
                          <div className="flex justify-between mt-2 text-xs text-gray-500">
                            <span>Mo</span>
                            <span>Di</span>
                            <span>Mi</span>
                            <span>Do</span>
                            <span>Fr</span>
                            <span>Sa</span>
                            <span>So</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card className="md:col-span-3">
                        <CardHeader>
                          <CardTitle>Kommende Termine</CardTitle>
                          <CardDescription>Planen Sie Ihre nächsten Reinigungen</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="schedule" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Ihr Reinigungszeitplan</CardTitle>
                        <CardDescription>Verwalten Sie Ihre regelmäßigen und einmaligen Termine</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Melden Sie sich an, um Ihren vollständigen Reinigungszeitplan zu sehen und zu verwalten.
                        </p>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="reports" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Reinigungsberichte</CardTitle>
                        <CardDescription>Detaillierte Berichte über durchgeführte Reinigungen</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Melden Sie sich an, um auf Ihre detaillierten Reinigungsberichte zuzugreifen.
                        </p>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </motion.div>

          <div className="mt-8 text-center">
            <Button asChild size="lg">
              <Link href="/book">Jetzt Reinigung buchen</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

