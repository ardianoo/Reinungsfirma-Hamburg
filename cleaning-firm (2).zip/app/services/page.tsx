import { CardFooter } from "@/components/ui/card"
import Link from "next/link"
import { ArrowRight, CheckCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SiteFooter } from "@/components/site-footer"
import { SiteLogo } from "@/components/site-logo"
import { MobileHeader } from "@/components/mobile-header"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 hidden md:flex">
            <SiteLogo className="mr-6" />
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/" className="transition-colors hover:text-primary">
                Startseite
              </Link>
              <Link href="/services" className="transition-colors hover:text-primary text-primary">
                Leistungen
              </Link>
              <Link href="/pricing" className="transition-colors hover:text-primary">
                Preise
              </Link>
              <Link href="/contact" className="transition-colors hover:text-primary">
                Kontakt
              </Link>
            </nav>
          </div>
          <div className="ml-auto hidden md:flex items-center space-x-4">
            <Button asChild className="hidden md:flex">
              <Link href="/book">Jetzt Buchen</Link>
            </Button>
          </div>
        </div>
        <MobileHeader />
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Unsere Reinigungsleistungen</h1>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Umfassende Reinigungslösungen, die auf Ihre spezifischen Bedürfnisse zugeschnitten sind
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-3">
              <Card className="flex flex-col">
                <CardHeader>
                  <CardTitle>Wohnungsreinigung</CardTitle>
                  <CardDescription>Halten Sie Ihr Zuhause makellos und gesund</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="aspect-video overflow-hidden rounded-lg mb-4">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-chaitaastic-1918291.jpg-1Zy1PbcWtjlCt9sdKv1G3cBswE3Mav.jpeg"
                      alt="Moderne Wohnung"
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <ul className="grid gap-2 mb-4">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Regelmäßige Reinigung aller Wohnbereiche</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Küchen- und Badezimmerdesinfektion</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Abstauben und Staubsaugen</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Bodenreinigung und -politur</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Innenreinigung der Fenster</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full">
                    <Link href="/book?service=residential">
                      Wohnungsreinigung buchen
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <CardTitle>Büroreinigung</CardTitle>
                  <CardDescription>Professionelle Lösungen für Unternehmen</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="aspect-video overflow-hidden rounded-lg mb-4">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-seven11nash-380768.jpg-9hF8kJt0b0shvapHKb8MlOWKut0zzR.jpeg"
                      alt="Modernes Büro"
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <ul className="grid gap-2 mb-4">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Büroreinigung und -wartung</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Reinigung von Einzelhandelsflächen</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Bodenpflege für stark frequentierte Bereiche</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Sanitärreinigung</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Müllentsorgung und Recycling</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full">
                    <Link href="/book?service=commercial">
                      Büroreinigung buchen
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <CardTitle>Ein-/Auszugsreinigung</CardTitle>
                  <CardDescription>Starten Sie frisch in Ihrem neuen Raum</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="aspect-video overflow-hidden rounded-lg mb-4">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-ketut-subiyanto-4245922.jpg-zgtXrp8cDHtANbDLj1HPbm9MvpG0I2.jpeg"
                      alt="Ein-/Auszugsreinigung"
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <ul className="grid gap-2 mb-4">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Komplette Leerraumreinigung</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Reinigung von Schränken und Schubladen innen</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Wand- und Fußleistenreinigung</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Fensterbank- und Schienensäuberung</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                      <span>Gerätereinigung innen und außen</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full">
                    <Link href="/book?service=move-in-out">
                      Ein-/Auszugsreinigung buchen
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Bereit loszulegen?</h2>
                <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Buchen Sie Ihren Reinigungsservice noch heute und erleben Sie den CleanPro Unterschied
                </p>
              </div>
              <Button asChild size="lg" variant="secondary">
                <Link href="/book">Jetzt einen Service buchen</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}

