import Link from "next/link"
import { SiteFooter } from "@/components/site-footer"
import { SiteLogo } from "@/components/site-logo"
import { MobileHeader } from "@/components/mobile-header"
import { Button } from "@/components/ui/button"

export default function CookiesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 hidden md:flex">
            <SiteLogo className="mr-6" />
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/" className="transition-colors hover:text-primary">
                Startseite
              </Link>
              <Link href="/services" className="transition-colors hover:text-primary">
                Leistungen
              </Link>
              <Link href="/pricing" className="transition-colors hover:text-primary">
                Preise
              </Link>
              <Link href="/contact" className="transition-colors hover:text-primary">
                Kontakt
              </Link>
            </nav>
          </div>
          <div className="ml-auto hidden md:flex items-center space-x-4">
            <Button asChild className="hidden md:flex">
              <Link href="/book">Jetzt Buchen</Link>
            </Button>
          </div>
        </div>
        <MobileHeader />
      </header>
      <main className="flex-1 container py-12">
        <div className="prose max-w-none">
          <h1>Cookie-Einstellungen</h1>

          <h2>Was sind Cookies?</h2>
          <p>
            Cookies sind kleine Textdateien, die auf Ihrem Computer oder mobilen Gerät gespeichert werden, wenn Sie
            unsere Website besuchen. Sie ermöglichen es uns, Ihren Browser beim nächsten Besuch wiederzuerkennen und
            bieten Ihnen ein besseres Nutzungserlebnis.
          </p>

          <h2>Welche Arten von Cookies verwenden wir?</h2>

          <h3>Notwendige Cookies</h3>
          <p>
            Diese Cookies sind für das Funktionieren unserer Website unerlässlich. Sie ermöglichen grundlegende
            Funktionen wie die Seitennavigation und den Zugriff auf sichere Bereiche der Website. Die Website kann ohne
            diese Cookies nicht richtig funktionieren.
          </p>

          <h3>Präferenz-Cookies</h3>
          <p>
            Diese Cookies ermöglichen es der Website, sich an Informationen zu erinnern, die die Art und Weise
            beeinflussen, wie sich die Website verhält oder aussieht, wie z.B. Ihre bevorzugte Sprache oder die Region,
            in der Sie sich befinden.
          </p>

          <h3>Statistik-Cookies</h3>
          <p>
            Diese Cookies helfen uns zu verstehen, wie Besucher mit unserer Website interagieren, indem sie
            Informationen anonym sammeln und melden. Sie helfen uns, die Leistung unserer Website zu verbessern.
          </p>

          <h3>Marketing-Cookies</h3>
          <p>
            Diese Cookies werden verwendet, um Besucher auf Websites zu verfolgen. Die Absicht ist, Anzeigen zu
            schalten, die für den einzelnen Nutzer relevant und ansprechend sind und damit für Publisher und
            Drittanbieter wertvoller sind.
          </p>

          <h2>Ihre Cookie-Einstellungen verwalten</h2>
          <p>
            Sie können Ihre Cookie-Einstellungen jederzeit ändern, indem Sie auf die Schaltfläche "Cookie-Einstellungen"
            klicken, die am unteren Rand jeder Seite unserer Website angezeigt wird.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <Button size="lg" variant="default">
              Alle Cookies akzeptieren
            </Button>
            <Button size="lg" variant="outline">
              Nur notwendige Cookies
            </Button>
            <Button size="lg" variant="outline">
              Einstellungen anpassen
            </Button>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}

